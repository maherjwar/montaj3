package com.example.editfast

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class SfxItem(val id: String, val name: String, val cat: String)
/** مؤثر صوتي مضاف على الخط الزمني للناتج */
data class SfxEvt(val t: Long, val id: String, val vol: Float = 1f)

/** مكتبة مؤثرات صوتية (236 ملفاً برخصة CC0، التفاصيل في assets/sfx/CREDITS.md) */
object SfxLib {
    val CATS = linkedMapOf("woosh" to "ووش", "hit" to "ضربات", "fun" to "مضحكة", "gl" to "جليتش", "ding" to "دينغ", "clk" to "نقرات",
        "rise" to "رايزر", "st" to "ستينغر", "pp" to "ورق", "pop" to "بوب", "gm" to "ألعاب", "tr" to "انتقالات", "mg" to "سحر",
        "lf" to "حياة", "ppl" to "أشخاص", "dr" to "طبول", "cash" to "فلوس", "ph" to "موبايل", "cam" to "كاميرا")
    private var cache: List<SfxItem>? = null
    private val pcmCache = HashMap<String, ShortArray>()
    private var mp: MediaPlayer? = null

    fun items(ctx: Context): List<SfxItem> {
        cache?.let { return it }
        val have = ctx.assets.list("sfx")?.map { it.substringBeforeLast('.') }?.toSet().orEmpty()
        val out = ArrayList<SfxItem>()
        runCatching {
            ctx.assets.open("sfx/CREDITS.md").bufferedReader().useLines { ls ->
                for (l in ls) {
                    if (!l.startsWith("| ")) continue
                    val p = l.split("|").map { it.trim() }
                    if (p.size < 4) continue
                    val id = p[1]
                    if (id in have) out += SfxItem(id, p[2], id.substringBefore('-'))
                }
            }
        }
        cache = out; return out
    }

    fun preview(ctx: Context, id: String) {
        runCatching {
            mp?.release()
            val afd = ctx.assets.openFd("sfx/$id.mp3")
            mp = MediaPlayer().apply { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); prepare(); start() }
        }
    }

    /** يفك ترميز المؤثر إلى PCM أحادي 44.1kHz لدمجه في التصدير */
    fun pcm(ctx: Context, id: String): ShortArray = pcmCache.getOrPut(id) { try { decode(ctx, id) } catch (e: Exception) { ShortArray(0) } }

    private fun decode(ctx: Context, id: String): ShortArray {
        val afd = ctx.assets.openFd("sfx/$id.mp3")
        val ex = MediaExtractor(); ex.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
        val fmt = ex.getTrackFormat(0); ex.selectTrack(0)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0); codec.start()
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val out = ByteArrayOutputStream(); val info = MediaCodec.BufferInfo()
        var inDone = false; var outDone = false
        while (!outDone) {
            if (!inDone) {
                val ii = codec.dequeueInputBuffer(10000)
                if (ii >= 0) {
                    val buf: ByteBuffer = codec.getInputBuffer(ii)!!
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                }
            }
            val oi = codec.dequeueOutputBuffer(info, 10000)
            if (oi >= 0) {
                val ob = codec.getOutputBuffer(oi)!!
                val chunk = ByteArray(info.size); ob.position(info.offset); ob.get(chunk); out.write(chunk)
                codec.releaseOutputBuffer(oi, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val nf = codec.outputFormat; sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            }
        }
        codec.stop(); codec.release(); ex.release(); afd.close()
        val sb = ByteBuffer.wrap(out.toByteArray()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val raw = ShortArray(sb.remaining()); sb.get(raw)
        val frames = raw.size / ch
        val mono = ShortArray(frames) { i -> var s = 0; for (c in 0 until ch) s += raw[i * ch + c].toInt(); (s / ch).toShort() }
        if (sr == Sfx.SR) return mono
        val n = (frames.toLong() * Sfx.SR / sr).toInt()
        return ShortArray(n) { i -> val p = i.toDouble() * sr / Sfx.SR; val a = p.toInt().coerceAtMost(frames - 1); val b = (a + 1).coerceAtMost(frames - 1); val f = p - a
            (mono[a] * (1 - f) + mono[b] * f).toInt().toShort() }
    }
}
