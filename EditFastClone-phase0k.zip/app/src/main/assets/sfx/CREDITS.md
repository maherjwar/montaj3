# مكتبة المؤثرات الصوتية — مصادرها

كل الأصوات دي **CC0 (ملكية عامة)**: مسموح استخدامها وتوزيعها في برنامج تجاري من غير إذن ولا ذكر للاسم. ذكرنا أصحابها هنا تقديرًا ليهم.

| id | الاسم | المصدر | الرخصة |
|---|---|---|---|
| woosh-air | ووش | «Whoosh» by qubodup — https://freesound.org/people/qubodup/sounds/60013/ | CC0 1.0 |
| woosh-double | ووش دبل | «classic double swwosh .wav» by martian — https://freesound.org/people/martian/sounds/19312/ | CC0 1.0 |
| woosh-soft | ووش ناعم | «Woosh» by florianreichelt — https://freesound.org/people/florianreichelt/sounds/683096/ | CC0 1.0 |
| woosh-long | سووش طويل | «swoosh» by Halgrimm — https://freesound.org/people/Halgrimm/sounds/169867/ | CC0 1.0 |
| woosh-space | سووش فضائي | «Space Swoosh - brighter» by GameAudio — https://freesound.org/people/GameAudio/sounds/220191/ | CC0 1.0 |
| woosh-chop | ووش قصير | «fast simple chop 5.aif» by dave.des — https://freesound.org/people/dave.des/sounds/127197/ | CC0 1.0 |
| woosh-quick | ووش سريع | «quick woosh» by florianreichelt — https://freesound.org/people/florianreichelt/sounds/683101/ | CC0 1.0 |
| woosh-breeze | ووش هوا | «Swosh swoosh whoosh air sound, free, high quality» by qubodup — https://freesound.org/people/qubodup/sounds/60026/ | CC0 1.0 |
| woosh-deep | ووش عميق | «Deep Whoosh #1» by Kinoton — https://freesound.org/people/Kinoton/sounds/351256/ | CC0 1.0 |
| woosh-deep2 | ووش عميق ٢ | «Deep Whoosh #2» by Kinoton — https://freesound.org/people/Kinoton/sounds/351259/ | CC0 1.0 |
| woosh-whip | ويب | «Throwing / Whip Effect» by denao270 — https://freesound.org/people/denao270/sounds/346373/ | CC0 1.0 |
| woosh-swish | سووش | «swoosh-1.mp3» by lesaucisson — https://freesound.org/people/lesaucisson/sounds/585257/ | CC0 1.0 |
| woosh-strong | ووش قوي | «woosh.wav» by freakinbehemoth — https://freesound.org/people/freakinbehemoth/sounds/243400/ | CC0 1.0 |
| woosh-reverse | ووش معكوس | «Whosh - Reversed/Reverbed breath» by PrdiChlp — https://freesound.org/people/PrdiChlp/sounds/181889/ | CC0 1.0 |
| woosh-swing | ووش خفيف | «Swing Woosh» by Jofae — https://freesound.org/people/Jofae/sounds/389590/ | CC0 1.0 |
| woosh-cinema | سووش سينما | «Swoosh 5» by Electroviolence — https://freesound.org/people/Electroviolence/sounds/234553/ | CC0 1.0 |
| woosh-low | ووش تقيل | «Woosh_Low_02.wav» by moogy73 — https://freesound.org/people/moogy73/sounds/425700/ | CC0 1.0 |
| woosh-sharp | سووش حاد | «Sharp Swosh 18» by qubodup — https://freesound.org/people/qubodup/sounds/60005/ | CC0 1.0 |
| woosh-kino | ووش نضيف | «Whoosh #1» by Kinoton — https://freesound.org/people/Kinoton/sounds/427823/ | CC0 1.0 |
| woosh-clean | سووش سريع | «Clean fast Swoosh.aiff» by Danjocross — https://freesound.org/people/Danjocross/sounds/507466/ | CC0 1.0 |
| tr-high | انتقال عالي | «Woosh_High_01.wav» by moogy73 — https://freesound.org/people/moogy73/sounds/425696/ | CC0 1.0 |
| tr-trailer | انتقال تريلر | «Sliding Trailer Woosh» by qubodup — https://freesound.org/people/qubodup/sounds/171255/ | CC0 1.0 |
| tr-glass | انتقال زجاج | «Glassy transition» by cabled_mess — https://freesound.org/people/cabled_mess/sounds/360734/ | CC0 1.0 |
| tr-backwards | ووش لورا | «Backwards Whoosh» by SlavicMagic — https://freesound.org/people/SlavicMagic/sounds/446010/ | CC0 1.0 |
| tr-shutter | سووش شاتر | «swoosh/shutter» by sgarrison2127 — https://freesound.org/people/sgarrison2127/sounds/176581/ | CC0 1.0 |
| tr-whoop | ووب | «Whoop» by cabled_mess — https://freesound.org/people/cabled_mess/sounds/361122/ | CC0 1.0 |
| tr-poof | بوف | «Poof of Smoke» by Planman — https://freesound.org/people/Planman/sounds/208111/ | CC0 1.0 |
| tr-low4 | انتقال تقيل | «Woosh_Low_04.wav» by moogy73 — https://freesound.org/people/moogy73/sounds/425698/ | CC0 1.0 |
| tr-quick | انتقال سريع | «Transition whoosh sound.wav» by SKsemi — https://freesound.org/people/SKsemi/sounds/432922/ | CC0 1.0 |
| tr-up | تكبير | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| tr-down | تصغير | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| rise-cymbal | سيمبال معكوس | «cymbal-reversed-glassy-resonance.wav» by burnttoys — https://freesound.org/people/burnttoys/sounds/9523/ | CC0 1.0 |
| rise-shiny | سيمبال لامع | «Reverse Cymbal Shiny» by loganzsound — https://freesound.org/people/loganzsound/sounds/774635/ | CC0 1.0 |
| rise-long | رايزر | «Riser sound effect long.wav» by syntheffects — https://freesound.org/people/syntheffects/sounds/685255/ | CC0 1.0 |
| rise-short | رايزر قصير | «Riser» by Rizzard — https://freesound.org/people/Rizzard/sounds/561207/ | CC0 1.0 |
| rise-simple | رايزر بسيط | «Simple Riser» by SoundEffectsForAll — https://freesound.org/people/SoundEffectsForAll/sounds/840719/ | CC0 1.0 |
| rise-scare | تشويق | «Jumpscare sound/buildup» by Cman634 — https://freesound.org/people/Cman634/sounds/235357/ | CC0 1.0 |
| rise-tension | توتر | «Tension 2» by Cman634 — https://freesound.org/people/Cman634/sounds/235352/ | CC0 1.0 |
| rise-crash | رايزر وضربة | «rise-crash.wav» by soneproject — https://freesound.org/people/soneproject/sounds/334522/ | CC0 1.0 |
| rise-sweep | سويب | «sweep.wav» by reathance — https://freesound.org/people/reathance/sounds/503815/ | CC0 1.0 |
| rise-charge | شحن | «Charge Up» by magnuswaker — https://freesound.org/people/magnuswaker/sounds/555060/ | CC0 1.0 |
| rise-uplift | أبليفت | «uplift waterdrop.wav» by cubix — https://freesound.org/people/cubix/sounds/124545/ | CC0 1.0 |
| rise-metal | رايزر معدني | «Metallic Riser.wav» by HenryRichard — https://freesound.org/people/HenryRichard/sounds/451653/ | CC0 1.0 |
| rise-crashrev | كراش معكوس | «Reversed Crash Cymbal» by TheEndOfACycle — https://freesound.org/people/TheEndOfACycle/sounds/674291/ | CC0 1.0 |
| hit-boom | بوم | «big boom» by SamsterBirdies — https://freesound.org/people/SamsterBirdies/sounds/435695/ | CC0 1.0 |
| hit-bass | بيز دروب | «SUB OCEANO A sharp.wav» by uzerx — https://freesound.org/people/uzerx/sounds/81144/ | CC0 1.0 |
| hit-sub | ساب دروب | «SUB OCEANO A.wav» by uzerx — https://freesound.org/people/uzerx/sounds/81145/ | CC0 1.0 |
| hit-cinema | ضربة سينما | «Hit reverb (natural)» by xkeril — https://freesound.org/people/xkeril/sounds/701309/ | CC0 1.0 |
| hit-dark | ضربة غامقة | «Hit reverb (dark)» by xkeril — https://freesound.org/people/xkeril/sounds/701308/ | CC0 1.0 |
| hit-bright | ضربة لامعة | «Bright sfx hit» by xkeril — https://freesound.org/people/xkeril/sounds/736849/ | CC0 1.0 |
| hit-sonar | ضربة سونار | «One hit (sonar inspired)» by xkeril — https://freesound.org/people/xkeril/sounds/736851/ | CC0 1.0 |
| hit-thud | دبدبة | «thud.wav» by OtisJames — https://freesound.org/people/OtisJames/sounds/215162/ | CC0 1.0 |
| hit-bigthud | خبطة | «big thud2.wav» by Reitanna — https://freesound.org/people/Reitanna/sounds/332668/ | CC0 1.0 |
| hit-punch | بوكس | «PUNCH-BOXING-01.wav» by newagesoup — https://freesound.org/people/newagesoup/sounds/348244/ | CC0 1.0 |
| hit-man | لكمة | «Man getting hit» by Under7dude — https://freesound.org/people/Under7dude/sounds/163441/ | CC0 1.0 |
| hit-slap | قلم | «Slap.wav» by MootMcnoodles — https://freesound.org/people/MootMcnoodles/sounds/444407/ | CC0 1.0 |
| hit-punchverb | لكمة بصدى | «PUNCH-BOXING-06-REVERB.wav» by newagesoup — https://freesound.org/people/newagesoup/sounds/348245/ | CC0 1.0 |
| hit-k-punch | لكمة تقيلة | Kenney — impact-sounds (www.kenney.nl) | CC0 1.0 |
| hit-k-metal | حديد | Kenney — impact-sounds (www.kenney.nl) | CC0 1.0 |
| hit-k-glass | زجاج | Kenney — impact-sounds (www.kenney.nl) | CC0 1.0 |
| hit-k-bell | جرس معدن | Kenney — impact-sounds (www.kenney.nl) | CC0 1.0 |
| hit-k-explode | انفجار عميق | Kenney — sci-fi-sounds (www.kenney.nl) | CC0 1.0 |
| hit-k-crunch | انفجار | Kenney — sci-fi-sounds (www.kenney.nl) | CC0 1.0 |
| pop-pop | بوب | «Pop sound» by deraj — https://freesound.org/people/deraj/sounds/202230/ | CC0 1.0 |
| pop-cartoon | بوب كرتون | «Cartoon Pop (Clean)» by unfa — https://freesound.org/people/unfa/sounds/245645/ | CC0 1.0 |
| pop-2 | بوب ٢ | «Pop 2» by D.S.G. — https://freesound.org/people/D.S.G./sounds/244654/ | CC0 1.0 |
| pop-3 | بوب ٣ | «Pop 5» by D.S.G. — https://freesound.org/people/D.S.G./sounds/244657/ | CC0 1.0 |
| pop-balloon | بلونة | «Balloon Pop / Christmas cracker / Confetti Cannon» by Breviceps — https://freesound.org/people/Breviceps/sounds/458398/ | CC0 1.0 |
| pop-drip | نقطة | «cartoon pop or drip» by AlaskaRobotics — https://freesound.org/people/AlaskaRobotics/sounds/221091/ | CC0 1.0 |
| pop-mouth | بوب بالبوق | «mouthPop_02.wav» by carlSablowEdwards — https://freesound.org/people/carlSablowEdwards/sounds/47498/ | CC0 1.0 |
| pop-bubble | فقاعة | «Bubble Pop» by TheBuilder15 — https://freesound.org/people/TheBuilder15/sounds/411462/ | CC0 1.0 |
| pop-small | بوب صغير | «Pop 5.ogg» by FourthWoods — https://freesound.org/people/FourthWoods/sounds/439186/ | CC0 1.0 |
| pop-mouth2 | بوب ٤ | «Mouth pop» by jcallison — https://freesound.org/people/jcallison/sounds/258269/ | CC0 1.0 |
| pop-pluck | نقرة | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| pop-drop | وقعة | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| clk-mouse | كليك ماوس | «Mouse Click» by HunteR4708 — https://freesound.org/people/HunteR4708/sounds/256455/ | CC0 1.0 |
| clk-single | كليك | «mouse-click-single-00.flac» by pbimal — https://freesound.org/people/pbimal/sounds/534103/ | CC0 1.0 |
| clk-double | دبل كليك | «mouse-click-double-00.flac» by pbimal — https://freesound.org/people/pbimal/sounds/534104/ | CC0 1.0 |
| clk-menu | اختيار | «Menu Selection Click» by NenadSimic — https://freesound.org/people/NenadSimic/sounds/171697/ | CC0 1.0 |
| clk-button | زرار | «Videogame Menu BUTTON CLICK» by Christopherderp — https://freesound.org/people/Christopherderp/sounds/342200/ | CC0 1.0 |
| clk-typing | كتابة كيبورد | «Keyboard typing» by Breviceps — https://freesound.org/people/Breviceps/sounds/447909/ | CC0 1.0 |
| clk-mech | كيبورد ميكانيكي | «MECH-KEYBOARD-01.wav» by newagesoup — https://freesound.org/people/newagesoup/sounds/348239/ | CC0 1.0 |
| clk-enter | إنتر | «Pressing Enter» by HunteR4708 — https://freesound.org/people/HunteR4708/sounds/256435/ | CC0 1.0 |
| clk-typewriter | آلة كاتبة | «Typewriter snippet 03» by cabled_mess — https://freesound.org/people/cabled_mess/sounds/360601/ | CC0 1.0 |
| clk-carriage | آلة كاتبة وجرس | «Typewriter bell & carriage reset» by knufds — https://freesound.org/people/knufds/sounds/345955/ | CC0 1.0 |
| clk-tding | جرس آلة كاتبة | «Typewriter Ding.wav» by NHumphrey — https://freesound.org/people/NHumphrey/sounds/204466/ | CC0 1.0 |
| clk-k1 | كليك هادي | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| clk-k2 | اختيار ٢ | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| clk-k3 | سويتش | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| clk-k4 | توجل | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| ding-correct | صح | «Correct.mp3» by LittleRainySeasons — https://freesound.org/people/LittleRainySeasons/sounds/335908/ | CC0 1.0 |
| ding-notify | إشعار | «Notification Sound» by yfjesse — https://freesound.org/people/yfjesse/sounds/235911/ | CC0 1.0 |
| ding-tada | تادا | «Tada Fanfare A» by plasterbrain — https://freesound.org/people/plasterbrain/sounds/397355/ | CC0 1.0 |
| ding-tada2 | تادا ٢ | «Tada Fanfare G» by plasterbrain — https://freesound.org/people/plasterbrain/sounds/397353/ | CC0 1.0 |
| ding-happy | جرس فرح | «Ringing bell - happy.wav» by domrodrig — https://freesound.org/people/domrodrig/sounds/116779/ | CC0 1.0 |
| ding-success | نجاح | «Short Success Sound Glockenspiel Treasure Video Game.mp3» by FunWithSound — https://freesound.org/people/FunWithSound/sounds/456965/ | CC0 1.0 |
| ding-bell | جرس نجاح | «success_bell» by MLaudio — https://freesound.org/people/MLaudio/sounds/511484/ | CC0 1.0 |
| ding-door | جرس الباب | «DoorBell Shortened» by jwheeler91 — https://freesound.org/people/jwheeler91/sounds/442280/ | CC0 1.0 |
| ding-micro | دينج ميكرويف | «microwave ding.WAV» by samplecat — https://freesound.org/people/samplecat/sounds/11587/ | CC0 1.0 |
| ding-wrong | غلط | «Wrong» by Raclure — https://freesound.org/people/Raclure/sounds/483598/ | CC0 1.0 |
| ding-school | جرس مدرسة | «School bell.wav» by deleted_user_7020630 — https://freesound.org/people/deleted_user_7020630/sounds/378394/ | CC0 1.0 |
| ding-k-ok | تأكيد | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| ding-k-err | خطأ | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| ding-k-q | سؤال | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| ding-k-bong | بونج | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| cash-register | كاشنج | «Cash Register Purchase» by Zott820 — https://freesound.org/people/Zott820/sounds/209578/ | CC0 1.0 |
| cash-fake | كاشير | «Cash Register Fake.wav» by CapsLok — https://freesound.org/people/CapsLok/sounds/184438/ | CC0 1.0 |
| cash-coins | فكة | «Coin dropping.wav» by Jace — https://freesound.org/people/Jace/sounds/17502/ | CC0 1.0 |
| cash-money | فلوس | «MONEY_001.wav» by rolandseer — https://freesound.org/people/rolandseer/sounds/443334/ | CC0 1.0 |
| cash-bag | شنطة فلوس | «Money Bag» by PhilSavlem — https://freesound.org/people/PhilSavlem/sounds/338260/ | CC0 1.0 |
| cash-coin | عملات | «Coins» by Mateusz_Chenc — https://freesound.org/people/Mateusz_Chenc/sounds/512216/ | CC0 1.0 |
| cash-pickup | لقطة فلوس | «Money Pickup» by LeMudCrab — https://freesound.org/people/LeMudCrab/sounds/163451/ | CC0 1.0 |
| cash-drawer | درج الكاشير | «cash drawer and receipt.wav» by kalisemorrison — https://freesound.org/people/kalisemorrison/sounds/202531/ | CC0 1.0 |
| cash-k-hand | عملات في الإيد | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| cam-shutter | شاتر | «350d shutter.wav» by xef6 — https://freesound.org/people/xef6/sounds/61059/ | CC0 1.0 |
| cam-click | كاميرا | «Nice Camera click.wav» by mmaruska — https://freesound.org/people/mmaruska/sounds/167556/ | CC0 1.0 |
| cam-vintage | فلاش قديم | «Vintage Camera Flash Powder and Shutter» by Werra — https://freesound.org/people/Werra/sounds/232130/ | CC0 1.0 |
| cam-flash | فلاش | «Camera with Flash Sound and then Charge (fast)» by RegoneFF — https://freesound.org/people/RegoneFF/sounds/456988/ | CC0 1.0 |
| cam-shutter2 | شاتر ٢ | «camera shutter.wav» by mywhats — https://freesound.org/people/mywhats/sounds/175517/ | CC0 1.0 |
| cam-dslr | شاتر DSLR | «dslr-shutter.wav» by benjohansen — https://freesound.org/people/benjohansen/sounds/87149/ | CC0 1.0 |
| gl-vhs | جليتش VHS | «VHS Glitch» by Sassaby — https://freesound.org/people/Sassaby/sounds/264935/ | CC0 1.0 |
| gl-corrupt | جليتش | «Glitch Corruption» by dotY21 — https://freesound.org/people/dotY21/sounds/348585/ | CC0 1.0 |
| gl-crackle | جليتش طقطقة | «crackle_glitch» by dotY21 — https://freesound.org/people/dotY21/sounds/362510/ | CC0 1.0 |
| gl-static | تشويش | «Electric static interference sound» by dotY21 — https://freesound.org/people/dotY21/sounds/347698/ | CC0 1.0 |
| gl-digital | جليتش ديجيتال | «Digital Glitch_v2.wav» by tadaizm — https://freesound.org/people/tadaizm/sounds/458064/ | CC0 1.0 |
| gl-electric | كهربا | «Electricity Sound» by NachtmahrTV — https://freesound.org/people/NachtmahrTV/sounds/556717/ | CC0 1.0 |
| gl-spark | شرارة | «Spark» by elliott.klein — https://freesound.org/people/elliott.klein/sounds/189630/ | CC0 1.0 |
| gl-zap | زاب | «Zap.wav» by TRNGLE — https://freesound.org/people/TRNGLE/sounds/367960/ | CC0 1.0 |
| gl-beep | بيب | «beep4.wav» by thisusernameis — https://freesound.org/people/thisusernameis/sounds/426888/ | CC0 1.0 |
| gl-beep2 | بيب ٢ | «Beep Sound» by Entershift — https://freesound.org/people/Entershift/sounds/704134/ | CC0 1.0 |
| gl-error | إيرور | «Error Signal 2» by Breviceps — https://freesound.org/people/Breviceps/sounds/445978/ | CC0 1.0 |
| gl-8bit | إيرور ٨ بت | «8-Bit - Error» by Breviceps — https://freesound.org/people/Breviceps/sounds/450616/ | CC0 1.0 |
| gl-radio | لاسلكي | «Radio Sign Off / Squelch» by JovianSounds — https://freesound.org/people/JovianSounds/sounds/524205/ | CC0 1.0 |
| gl-walkie | ووكي توكي | «Walkie Talkie Beep» by SoundBiterSFX — https://freesound.org/people/SoundBiterSFX/sounds/732209/ | CC0 1.0 |
| gl-k-ui | جليتش خفيف | Kenney — interface-sounds (www.kenney.nl) | CC0 1.0 |
| gl-k-pc | كمبيوتر | Kenney — sci-fi-sounds (www.kenney.nl) | CC0 1.0 |
| fun-boing | بوينج | «Cartoon Boing.wav» by reelworldstudio — https://freesound.org/people/reelworldstudio/sounds/161122/ | CC0 1.0 |
| fun-boink | بوينك | «Boink_v3.wav» by simon.rue — https://freesound.org/people/simon.rue/sounds/61847/ | CC0 1.0 |
| fun-boing2 | بوينج ٢ | «Boing 2» by magnuswaker — https://freesound.org/people/magnuswaker/sounds/540790/ | CC0 1.0 |
| fun-blink | رمش | «cartoon blinking» by zevcuk — https://freesound.org/people/zevcuk/sounds/348845/ | CC0 1.0 |
| fun-splat | طرطشة | «Mud Splat» by Breviceps — https://freesound.org/people/Breviceps/sounds/445109/ | CC0 1.0 |
| fun-honk | كلاكس | «Car Honking» by MicktheMicGuy — https://freesound.org/people/MicktheMicGuy/sounds/434878/ | CC0 1.0 |
| fun-buzzer | إجابة غلط | «Buzzer sounds (Wrong answer / Error)» by Breviceps — https://freesound.org/people/Breviceps/sounds/493163/ | CC0 1.0 |
| fun-lose | خسارة | «Lose_Funny_Retro_Video Game» by cabled_mess — https://freesound.org/people/cabled_mess/sounds/371451/ | CC0 1.0 |
| fun-wahwah | واه واه | «horn_fail_wahwah_3.wav» by TaranP — https://freesound.org/people/TaranP/sounds/362204/ | CC0 1.0 |
| fun-pan | طاسة | «Metal Hit Cartoon» by Johnnyfarmer — https://freesound.org/people/Johnnyfarmer/sounds/209771/ | CC0 1.0 |
| fun-jaw | جو هارب | «jaw_harp2.mp3» by 3bagbrew — https://freesound.org/people/3bagbrew/sounds/95600/ | CC0 1.0 |
| fun-goat | معزة | «Goat Sound 2.wav» by Erokia — https://freesound.org/people/Erokia/sounds/188182/ | CC0 1.0 |
| fun-wink | غمزة | «cartoon_wink_magic_sparkle.wav» by MLaudio — https://freesound.org/people/MLaudio/sounds/511485/ | CC0 1.0 |
| fun-rimshot | ريمشوت | «Rimshot (sweet)» by Sajmund — https://freesound.org/people/Sajmund/sounds/132418/ | CC0 1.0 |
| fun-slide | صفارة | «Slide Whistle.wav» by WalliumVA — https://freesound.org/people/WalliumVA/sounds/672965/ | CC0 1.0 |
| fun-popgun | فشنك | «Pop Gun» by qubodup — https://freesound.org/people/qubodup/sounds/814305/ | CC0 1.0 |
| fun-brakes | فرامل | «Tires Squeaking.aif» by RutgerMuller — https://freesound.org/people/RutgerMuller/sounds/104026/ | CC0 1.0 |
| fun-glass | كسر زجاج | «Glass Break» by unfa — https://freesound.org/people/unfa/sounds/221528/ | CC0 1.0 |
| ppl-cheer | تشجيع | «Cheer 2.wav» by jayfrosting — https://freesound.org/people/jayfrosting/sounds/333404/ | CC0 1.0 |
| ppl-laugh | ضحك جمهور | «Crowd laugh.wav» by deleted_user_2104797 — https://freesound.org/people/deleted_user_2104797/sounds/324894/ | CC0 1.0 |
| ppl-small | ضحك ناس | «Small Crowd Laughing» by snakebarney — https://freesound.org/people/snakebarney/sounds/138112/ | CC0 1.0 |
| ppl-woman | ضحكة | «Woman laugh» by Kalibrk — https://freesound.org/people/Kalibrk/sounds/433921/ | CC0 1.0 |
| ppl-girl | ضحكة بنت | «Girl Laugh.wav» by lmbubec — https://freesound.org/people/lmbubec/sounds/119450/ | CC0 1.0 |
| ppl-gasp | شهقة | «Gasp.» by bacruz666 — https://freesound.org/people/bacruz666/sounds/341908/ | CC0 1.0 |
| ppl-gasp2 | شهقة ٢ | «Gasp.wav» by Dvideoguy — https://freesound.org/people/Dvideoguy/sounds/207779/ | CC0 1.0 |
| ppl-shock | صدمة | «Shocked gasp.wav» by GentlemanWalrus — https://freesound.org/people/GentlemanWalrus/sounds/180005/ | CC0 1.0 |
| ppl-start | يلا | «Game Start» by plasterbrain — https://freesound.org/people/plasterbrain/sounds/243020/ | CC0 1.0 |
| mg-magic | سحر | «SFX Magic» by renatalmar — https://freesound.org/people/renatalmar/sounds/264981/ | CC0 1.0 |
| mg-poof | بوف سحر | «Poof in cloud» by Mateusz_Chenc — https://freesound.org/people/Mateusz_Chenc/sounds/512217/ | CC0 1.0 |
| mg-heal | لمعة | «Heal - Rpg» by colorsCrimsonTears — https://freesound.org/people/colorsCrimsonTears/sounds/562292/ | CC0 1.0 |
| mg-crystal | لمعة كريستال | «Crystal Twinkle» by LaurenPonder — https://freesound.org/people/LaurenPonder/sounds/639429/ | CC0 1.0 |
| mg-spell | تعويذة | «Magic spell (small positive)» by Nakhas — https://freesound.org/people/Nakhas/sounds/506939/ | CC0 1.0 |
| mg-win | فوز سحري | «magic_game_win_success.wav» by MLaudio — https://freesound.org/people/MLaudio/sounds/615099/ | CC0 1.0 |
| mg-fairy | جنية | «Fairy FlyBy 2.aif» by timgormly — https://freesound.org/people/timgormly/sounds/148047/ | CC0 1.0 |
| mg-bubbles | فقاعات | «bubbles-03.aif» by kijjaz — https://freesound.org/people/kijjaz/sounds/16738/ | CC0 1.0 |
| mg-magic2 | سحر ٢ | «Magic SFX for Games » by suntemple — https://freesound.org/people/suntemple/sounds/241809/ | CC0 1.0 |
| mg-strike | ضربة سحر | «Magic Strike.wav» by Aleks41 — https://freesound.org/people/Aleks41/sounds/406063/ | CC0 1.0 |
| mg-k-shield | درع | Kenney — sci-fi-sounds (www.kenney.nl) | CC0 1.0 |
| pp-flip1 | قلب ورقة | «paper flip 1.wav» by gynation — https://freesound.org/people/gynation/sounds/82377/ | CC0 1.0 |
| pp-flip2 | قلب ورقة ٢ | «paper flip 2.wav» by gynation — https://freesound.org/people/gynation/sounds/82378/ | CC0 1.0 |
| pp-flip3 | قلب ورقة ٣ | «paper flip 3.wav» by gynation — https://freesound.org/people/gynation/sounds/82379/ | CC0 1.0 |
| pp-page | قلب صفحة | «turnPage.mp3» by partheeban — https://freesound.org/people/partheeban/sounds/457767/ | CC0 1.0 |
| pp-stamp | ختم | «Stamp» by kermite607 — https://freesound.org/people/kermite607/sounds/362624/ | CC0 1.0 |
| pp-tear | قطع ورق | «tearing paper4.wav» by keweldog — https://freesound.org/people/keweldog/sounds/181773/ | CC0 1.0 |
| pp-circle | ماركر دايرة | «Sharpie marker drawing circle 01.wav» by elliott.klein — https://freesound.org/people/elliott.klein/sounds/321137/ | CC0 1.0 |
| pp-arrow | رسم سهم | «Felt tip pen drawing arrow 01.wav» by elliott.klein — https://freesound.org/people/elliott.klein/sounds/321136/ | CC0 1.0 |
| pp-sign | إمضا | «PEN SIGNATURE SIGNING 2.wav» by ListenTonyBoy — https://freesound.org/people/ListenTonyBoy/sounds/326961/ | CC0 1.0 |
| pp-rustle | خشخشة ورق | «Paper Rustle» by BenjaminNelan — https://freesound.org/people/BenjaminNelan/sounds/353125/ | CC0 1.0 |
| pp-k-book | تقليب كتاب | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| pp-k-close | قفل كتاب | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| ph-message | رسالة | «Message Notification» by UnderlinedDesigns — https://freesound.org/people/UnderlinedDesigns/sounds/328243/ | CC0 1.0 |
| ph-notify | نوتيفيكيشن | «Notification Sound 2» by deadrobotmusic — https://freesound.org/people/deadrobotmusic/sounds/750608/ | CC0 1.0 |
| ph-notify2 | نوتيفيكيشن ٢ | «Notification Sound 3» by deadrobotmusic — https://freesound.org/people/deadrobotmusic/sounds/750609/ | CC0 1.0 |
| ph-three | تلات نغمات | «Three-Note Doorbell or Notification» by eqylizer — https://freesound.org/people/eqylizer/sounds/624599/ | CC0 1.0 |
| ph-vibrate | اهتزاز | «vibration.mp3» by D0tDashDialUp — https://freesound.org/people/D0tDashDialUp/sounds/627766/ | CC0 1.0 |
| ph-swipe | سوايب | «whip02.wav» by snowflakes — https://freesound.org/people/snowflakes/sounds/72190/ | CC0 1.0 |
| ph-swipe2 | سوايب ٢ | «Throw/Swipe» by mrickey13 — https://freesound.org/people/mrickey13/sounds/515625/ | CC0 1.0 |
| dr-roll | طبلة | «buzz roll.wav» by bigjoedrummer — https://freesound.org/people/bigjoedrummer/sounds/77305/ | CC0 1.0 |
| dr-clock | ساعة | «Ticking Stopwatch (dry)» by DavidJGurney — https://freesound.org/people/DavidJGurney/sounds/275802/ | CC0 1.0 |
| dr-tick | تكتكة | «ticking of the clock 02.wav» by blukotek — https://freesound.org/people/blukotek/sounds/412750/ | CC0 1.0 |
| dr-heart | دقات قلب | «HeartBeatNEW.aif» by Woodingp — https://freesound.org/people/Woodingp/sounds/116642/ | CC0 1.0 |
| dr-heavy | دقة قلب تقيلة | «Heavy Heartbeat» by MickBoere — https://freesound.org/people/MickBoere/sounds/276578/ | CC0 1.0 |
| dr-scratch | سكراتش | «Scratch3.wav» by klangkonserve — https://freesound.org/people/klangkonserve/sounds/205982/ | CC0 1.0 |
| dr-rewind | ترجيع | «17_REWIND STOP.wav» by gear_clinkz — https://freesound.org/people/gear_clinkz/sounds/613352/ | CC0 1.0 |
| dr-vinyl | أسطوانة لورا | «Vinyl Rewind Bright 01» by loganzsound — https://freesound.org/people/loganzsound/sounds/842581/ | CC0 1.0 |
| dr-stop | وقفة شريط | «Stop_5.wav» by f_ilippo — https://freesound.org/people/f_ilippo/sounds/245847/ | CC0 1.0 |
| gm-power | باور أب | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-power2 | باور أب ٢ | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-power3 | باور أب ٣ | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-zap | زاب ديجيتال | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-laser | ليزر | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-phaser | فيزر | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-three | نغمات | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-pep | بيب لعبة | Kenney — digital-audio (www.kenney.nl) | CC0 1.0 |
| gm-blaster | ليزر كبير | Kenney — sci-fi-sounds (www.kenney.nl) | CC0 1.0 |
| gm-dice | زهر | Kenney — casino-audio (www.kenney.nl) | CC0 1.0 |
| gm-cards | كوتشينة | Kenney — casino-audio (www.kenney.nl) | CC0 1.0 |
| gm-chips | فيش | Kenney — casino-audio (www.kenney.nl) | CC0 1.0 |
| st-hit1 | لحن نجاح | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-hit2 | لحن نجاح ٢ | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-hit3 | لحن مفاجأة | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-sax1 | ساكس | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-sax2 | ساكس ٢ | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-steel1 | جيتار | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-steel2 | جيتار ٢ | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-pizzi1 | كمان نقر | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-pizzi2 | كمان نقر ٢ | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-nes1 | ٨ بت | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-nes2 | ٨ بت ٢ | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| st-nes3 | ٨ بت خسارة | Kenney — music-jingles (www.kenney.nl) | CC0 1.0 |
| lf-door | فتح باب | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| lf-doorclose | قفل باب | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| lf-creak | صرير | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| lf-cloth | هدوم | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| lf-knife | سكينة | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| lf-latch | مزلاج | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| lf-pot | حلة | Kenney — rpg-audio (www.kenney.nl) | CC0 1.0 |
| lf-step | خطوة | Kenney — impact-sounds (www.kenney.nl) | CC0 1.0 |
| lf-wood | خشب | Kenney — impact-sounds (www.kenney.nl) | CC0 1.0 |
| lf-soft | وقعة ناعمة | Kenney — impact-sounds (www.kenney.nl) | CC0 1.0 |
